// Visit https://api.openweathermap.org & then signup to get our API keys for free
module.exports = {
  key: "2529c61c5043c82b9e9e1b6ac607036f",
  base: "https://api.openweathermap.org/data/2.5/",
};
